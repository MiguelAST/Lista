import {electronics} from './List';

function Dictionary(){

    const tipo = electronics.filter(electronics =>
        electronics.tipo === 'Smartphone');

        const lista = tipo.map(electronic => 
        <ul>
        <li>
            <p>
               <b>{electronic.sku}:</b><br />
                {electronic.nombre}<br />
                {electronic.pantalla} <br />
                {electronic.precio} <br />
          </p>
        </li>
        </ul>
      );

     return(
    <>
          <p>Electronicos</p>

          <div>
            {lista}
          </div>
    </>
  
     )
     
    }
export default Dictionary