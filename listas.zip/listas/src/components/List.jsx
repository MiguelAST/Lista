export const electronics = [{
    id: 0,
    sku:'A001',
    tipo: 'Smartphone',
    nombre: 'Xiaomi',
    description: 'esta bonito',
    precio: 5000,
    ram: '6 ram',
    procesador: 'snapdragon 8000',
    pantalla: 'amoled',
    resolucion: 'hd'
  }, {
    id: 1,
    sku:'A002',   
    tipo: 'Smartphone',
    nombre: 'Poco x5',
    description: 'esta potente',
    precio: 8000,
    ram: '6 ram',
    procesador: 'snapdragon 9000',
    pantalla: 'amoled hd',
    resolucion: 'full Hd'}

];